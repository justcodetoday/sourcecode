Asegúrese que el motor ZincSearch(ZSE) está ejecutándose localmente, según la configuración por defecto que está descrita en el sitio oficial.

Indexar.go:	Contiene el programa que lee los emails guardados en una carpeta y todas las subcarpetas de ésta y los indexa utilizando el ZSE.
		Parametro requerido: 	El directorio raiz que contiene todos los archivos.
		Parametros opcionales: 	El número de archivos a cargar
					El nombre del indice con el que se almacenará en el ZSE
Ejemplo:
		indexar "C:/Datos/Emails/" 500 "Parcial"
En este caso, sólo se cargará los primeros 500 archivos que se encuentren dentro del directorio raiz y se creará el indice "Parcial"
Si sólo se especifica el directorio raiz, el programa cargará todos los archivos que se encuentren contenidos en dicho directorio y sub-directorios. El nombre del indice sera creado al azar siguiendo esta nomenclatura: xxxx_index, donde xxxx hace referencia a 4 letras escogidas al azar. 
Si se desea especificar el nombre del índice, pero se desconoce la cantidad de archivos que contiene el directorio raiz, pero quiere cargar todos los archivos, se debe ingresar un valor inferior a 1 o un numero que se estime mayor a la cantidad de archivos que contiene el directorio raiz, por ejemplo:

		indexar "C:\Datos\Emails" -1 "Parcial"
		indexar "C:\Datos\Emails" 50000000 "Parcial"

goserver.go:	Contiene el programa backend que recibe las peticiones del cliente y hace las consultas respectivas al ZSE, para luego enviar al cliente las respuestas. 
Para ejecutar:  go run goserver.go

Carpeta ui:	Contiene el frontend (Vue/CSSTailwind). Proporciona estas funcionalidades:

1) Cargar y seleccionar la lista de indices que contiene el ZSE			('ui/src/components/ListOfIndexes.vue')
2) Consultar los emails, ingresando la palabra clave que desean buscar		('ui/src/App.vue')

Ingresando al directorio ui:
1) Primero ejecute el comando: yarn
2) Segundo, ejecute: yarn serve
3) Por ultimo, abrir el navegador y cargar la aplicacion web en la direccion indicada.

