package main

import (
    "encoding/json"
    "bufio"
    "os"
    "fmt"
    "io/ioutil"
    "log"
    "strings"
    "math/rand"
    "time"
    "strconv"
    "sync"
    "net/http"
    _ "net/http/pprof"
    //"runtime/pprof"
)

//Required arguments:   The root directory that contains the files that will be uploaded to the ZincSearch Engine(ZSE).
//Optional arguments:   The number of files to be uploaded. If this parameter is set up, the program will only upload this quantity of files regardless the root directory contains a 
//                      higher number of files
//                      The name of the index, which will be used to create the index in ZSE
//
//The files will be processed to build one or more temporal repositories (Json format), which finally will be uploaded to the ZSE.
//
//There are 3 processes:
//1. EXTRACT DATA:      The program build a list of files (with their full paths) that contains the root directory. Based on this info, it determines the number of files to be uploaded. 
//2. TRANSFORM DATA:    The next task is to split this list in smaller lists and grouped in several groups which will be used to create the temporal repositories. 
//                      Then the temporal repositories are created and start the second process
//                      Finally, every group of list is processed to create every temporal repository using go routines
//3. LOAD DATA:         Upload the temporal repositories to the ZincSearch engine.

var mutex sync.Mutex

type Response struct {
	Msg   string  `json:"message"`
	Number int     `json:"record_count"`
}


type Extractor interface {
    Setup(root string) Extractor
    ExtractFiles(dirPath string) []string
}

type EmailExtractor struct {
    RootDir string           //Root directory that contains all the files to be uploaded to the ZSE
    List_of_files []string   //List of all files that the root directory contains
    IsSetup bool
}

func (et EmailExtractor) Setup(root string) Extractor{
    files, err := ioutil.ReadDir(root)
    if len(files) == 0 || err != nil {
        fmt.Println("Root directory is no a valid directory or is empty.")
        return nil
    }
    et.RootDir = root
    et.IsSetup = true
    return et
}

// This funtion returns the list of all files inside a root folder and subfolders
func (e EmailExtractor) ExtractFiles(dirPath string) []string {
    files, err := ioutil.ReadDir(dirPath)
    if err != nil {
        log.Fatal(err)
    }
    for _, file := range files {
        if file.IsDir(){
            e.List_of_files = e.ExtractFiles(dirPath + "/" + file.Name())   
        }else{
            e.List_of_files = append(e.List_of_files, dirPath + "/" + file.Name())
        }   
    }
    return e.List_of_files
}

func ExtractData(e Extractor) []string {
    obj, ok := e.(EmailExtractor)
    if ok {
        obj, ok = (obj.Setup(obj.RootDir)).(EmailExtractor)
        return obj.ExtractFiles(obj.RootDir)
    }
    return nil
}

type Transformer interface{
    Setup(list_of_files []string, num_file_to_read int, key_map map[string]int, index_name string, rnd_prefix string) Transformer
    CreateTmpRepo() ([]string)
    fillTemporalRepo(list_of_files *[]string, waitgroup *sync.WaitGroup, textWriter *bufio.Writer)
}

type EmailTransformer struct{
    Index_name string                   //Index's name to be created
    Key_map map[string]int              //The entries for the Json format that temporal repositories will have    
    List_of_files []string              //List of all files that the root directory contains
    Num_file_to_read int                //The number of files that will be processed and uploaled to the ZSE
    Repo_prefix string
    IsSetup bool
}

func (et EmailTransformer) Setup(list_of_files []string, num_file_to_read int, key_map map[string]int, index_name string, rnd_prefix string ) Transformer{
    et.Key_map = key_map
    et.List_of_files = list_of_files
    et.Num_file_to_read = num_file_to_read
    et.Index_name = index_name
    et.Repo_prefix = rnd_prefix
    et.IsSetup = true
    return et
}


func (et EmailTransformer) CreateTmpRepo() ([]string){
    var total_size_to_read int64            //The size in bytes of all files to be uploaded.
    var size_per_storage_to_upload int64    //The aprox size of every temporal repository
    var num_storages int                    //Number of temporal repositories to be created.
    var list_of_repo []string               //Repositories names
    var list_of_list [][]string             //Groups of files
    var l_list_of_list [][][]string         //List of groups that will be used to create temporary repositories. 
    var tmp_storage []*os.File              //Temporal repositories
    var textWriter []*bufio.Writer
    var json_file string
    size_per_storage_to_upload = 50000000   
    num_files_processed_thread := 80
    num_block_files := 1
    num_files_per_storage := 1
    iRepo := 0
    readfiles := 0
    umbral2 := 1
    ind := 0
    json_repo_name := et.Repo_prefix + "part_"
    if et.IsSetup != true{
        fmt.Println("EmailTransformer: CreateTmpRepo() requires setup has been done correctly.")
        return nil
    }
    //Initializing different parameter according to the number of temporal repositories to be created
    //Calculating the total size in bytes of all files to be uploaded
    for f := 0; f < et.Num_file_to_read; f++ {
        fi, err := os.Stat(et.List_of_files[f])
        if err != nil {
            log.Fatal(err)
        }
        total_size_to_read = total_size_to_read + fi.Size()
    }
    fmt.Println("Total size (bytes) to be read", total_size_to_read)

    //Calculating the total number of temporal repositories to be created
    if total_size_to_read > size_per_storage_to_upload {
        num_storages = int(total_size_to_read/size_per_storage_to_upload)
        if total_size_to_read%size_per_storage_to_upload > 0{
            num_storages++
        }
    }else{
        num_storages = 1
    }

   l_list_of_list = make([][][]string, num_storages)   
   textWriter = make([]*bufio.Writer, num_storages)
   tmp_storage = make([]*os.File, num_storages)
   fmt.Println("Number of files to be uploaded: ", et.Num_file_to_read)
   fmt.Println("Number of temporal repositories: ", num_storages)
   num_files_per_storage = int(et.Num_file_to_read / num_storages)
   
   if et.Num_file_to_read>1000 {
        num_block_files = int(num_files_per_storage)/num_files_processed_thread
   }

   umbral2 = num_files_per_storage/num_block_files
   list_of_list = make([][]string,(et.Num_file_to_read/umbral2)+1)
   
   for f := 0; f < len(et.List_of_files) && f < et.Num_file_to_read; f++ {
        list_of_list[ind] = append(list_of_list[ind], et.List_of_files[f])
        if f%(umbral2)==0 && f>0 {
            ind++
        }
   }

   // Create groups of files to be processed and storage in temporal file in disk, which will be uploaded to Zincsearch engine 
   for f := 0; f < len(list_of_list); f++ {
        if(len(list_of_list[f])>0){
           l_list_of_list[iRepo] = append(l_list_of_list[iRepo],list_of_list[f])
           readfiles = readfiles + len(list_of_list[f])
           if readfiles >= (int)(num_files_per_storage) {
              iRepo++
              readfiles = 0
           }
       }  
   }

    //Create the empty temporal repositories
    for g:=0; g<(int)(num_storages);g++{
        json_file = json_repo_name + strconv.Itoa(g)
        list_of_repo = append(list_of_repo, json_file)
        var _, err = os.Stat(json_file)

        if os.IsNotExist(err) {
            file1, err := os.Create(json_file)
            if err != nil {
                fmt.Println(err)
                return nil
            }else{
                tmp_storage[g] = file1
                textWriter[g] = bufio.NewWriter(file1)
            }
        } else {
            fmt.Println("File already exists: ", json_file)
            return nil
        }
    }
    
    //Fill every temporal repository with data Json formatted
    var wg sync.WaitGroup
    for z := 0; z < int(num_storages); z++ {
        for f := 0; f < len(l_list_of_list[z]); f++ {
            wg.Add(1)
            go et.fillTemporalRepo(&l_list_of_list[z][f], &wg, textWriter[z])
        }
    }
    wg.Wait()
    
    for f := 0; f < num_storages; f++ {
        textWriter[f].Flush()
        tmp_storage[f].Close()
    }

    return list_of_repo
}


// This function build a temporal repository, which will be upload to the ZincSearch
func (r EmailTransformer) fillTemporalRepo(list_of_files *[]string, waitgroup *sync.WaitGroup, textWriter *bufio.Writer) {
    var pair string
    var body_begin bool 
    var filesz int64
    filesz = 128*1024
    jsonContent := ""
    value := ""
    defer waitgroup.Done()

    for f := 0; f < len(*list_of_files); f++ {
        body_begin = false
        pair = ""

        // Read the whole content of the file
        file, err := os.Open((*list_of_files)[f])
        if err != nil {
            fmt.Printf("Could not open the file %s due to this %s error \n", (*list_of_files)[f], err)
        }else{
            fi, err := os.Stat((*list_of_files)[f])
            if err != nil {
                log.Fatal(err)
            }
            filesz = fi.Size()
        }
        fileScanner := bufio.NewScanner(file)
        buf := make([]byte, 0, filesz)
        fileScanner.Buffer(buf, int(filesz))
        fileScanner.Split(bufio.ScanLines)

        for fileScanner.Scan() {
            value = fileScanner.Text()
            if len(value)==0{ 
                if !body_begin{
                    pair = pair + "\"Body\": \""
                }
                body_begin = true;
                continue 
            }
            i := strings.Index(value, ":")
            if (i > -1) || body_begin == true{
                if body_begin{
                    value = strings.Replace(value,"\"","",-1)
                    if len(pair)<128000{
                        pair = pair + " " + value
                    }
                }else{
                    k := value[:i]
                    v := value[i+1:]
                    if (r.Key_map)[k]==1{
                        v = strings.Replace(v,"\"","",-1)
                        pair = pair + "\"" + k + "\": \"" + v + "\","        
                    }else{
                        v = strings.Replace(value,"\"","",-1)
                        pair = pair[:len(pair)-2] + v + "\","       
                    }
                }
            } else {
                value = strings.Replace(value,"\"","",-1)
                pair = pair[:len(pair)-2] + value +  "\","
            }

        }
        if err = file.Close(); err != nil {
            fmt.Printf("Could not close the file due to this %s error \n", err)
        }

        pair = strings.Replace(pair,"\\","\\\\",-1)
        pair = "{ \"index\" : { \"_index\" : \"" + r.Index_name + "\" } }\n" + "{" + pair + "\"" + "}\n"
        jsonContent = jsonContent + pair
    }    

    mutex.Lock()             
    _, err := textWriter.WriteString(jsonContent)
    mutex.Unlock()           

    if err != nil {
        log.Fatal(err)
    }
}

func TransformData(t Transformer) ([]string){
    obj, ok := t.(EmailTransformer)
    if ok {
        obj, ok = (obj.Setup(obj.List_of_files, obj.Num_file_to_read, obj.Key_map, obj.Index_name, obj.Repo_prefix)).(EmailTransformer)
        return obj.CreateTmpRepo()
    }else{
        return nil
    }
}

type Loader interface{
    Setup(url string, user string, pwd string, list_repo_name []string) Loader
    LoadBulk(list_repo_name []string)
    UploadFile(json_file string, waitgroup *sync.WaitGroup, client *http.Client)
}

type EmailLoader struct{
    Url string
    User string
    Pwd string
    List_repo_name []string
    IsSetup bool
}

func (el EmailLoader) Setup(url string, user string, pwd string, list_repo_name []string) Loader{
    el.Url = url
    el.User = user
    el.Pwd = pwd
    el.List_repo_name = list_repo_name
    el.IsSetup = true
    return el
}

func (el EmailLoader) LoadBulk(list_repo_name []string) {
    //Upload the temporal repositories to the ZSE
    fmt.Println("LOADING temporal repositories to the ZSE")
    var wg sync.WaitGroup
    client := http.Client{}
	for g:=0; g < len(list_repo_name); g++ {
		wg.Add(1)
		go el.UploadFile(list_repo_name[g], &wg, &client)
	}
    wg.Wait()
}

func LoadData(t Loader) {
    v, ok := t.(EmailLoader)
    if ok {
        v, ok = (v.Setup(v.Url, v.User, v.Pwd, v.List_repo_name)).(EmailLoader)
        v.LoadBulk(v.List_repo_name)
    }
}

func (el EmailLoader) UploadFile(json_file string, waitgroup *sync.WaitGroup, client *http.Client) {
    defer waitgroup.Done()

    f, err := os.Open(json_file)
    if err != nil {
        fmt.Println(err)
    }
    defer f.Close()
    req, err := http.NewRequest("POST", el.Url, f)
    if err != nil {
        fmt.Println(err)
    }
    req.SetBasicAuth(el.User, el.Pwd)
    req.Header.Set("Content-Type", "application/x-www-form-urlencoded")
    
    resp, err := client.Do(req)
    if err != nil {
        fmt.Println(err)
    }
        
    responseData, err := ioutil.ReadAll(resp.Body)
    if err != nil {
        fmt.Println(err)
    }
    defer resp.Body.Close()
    
    var responseObject Response
    json.Unmarshal(responseData, &responseObject)
    fmt.Printf(json_file + " " + responseObject.Msg + ": %s records\n", strconv.Itoa(responseObject.Number))
}


func main() {
	start := time.Now()
    rnd_prefix := createPrefix()     //Prefix to be used to assign names to the temporal repositories, index's name and CPU profile
    //UNCOMENT THIS SECTION TO ALLOW PROFILING
    /*    
    go func(){
        log.Println(http.ListenAndServe("localhost:6666",nil))
    }()

    fp, errp := os.Create(rnd_prefix + "_CPU_profile.pb.gz")
    if errp != nil {
        log.Fatal(errp)
    }
    errp = pprof.StartCPUProfile(fp)
    if errp != nil {
        log.Fatal(errp)
    }
    defer pprof.StopCPUProfile()
    */

    var num_file_to_read int        //The number of files that will be processed and uploaled to the ZSE
    var err error
    var index_name string           //The name of the index to be created in the ZSE
    var list_of_files []string   //List of all files that the root directory contains
    key_map := make(map[string]int)
    key_map["Message-ID"] = 1 
    key_map["Date"] = 1
    key_map["From"] = 1
    key_map["To"] = 1
    key_map["Subject"] = 1
    key_map["Mime-Version"] = 1
    key_map["Content-Type"] = 1
    key_map["Content-Transfer-Encoding"] = 1
    key_map["X-From"] = 1
    key_map["X-To"] = 1
    key_map["X-cc"] = 1
    key_map["X-bcc"] = 1
    key_map["X-Folder"] = 1
    key_map["X-Origin"] = 1
    key_map["X-FileName"] = 1    
   
   
    //Reading arguments
    args := os.Args[1:]
    if len(args)==0{
        fmt.Println("Usage: program Root_directory [Number of files to be uploaded] [Index's name]")
        return
    }
    
    if len(args)>=2{
        num_file_to_read, err = strconv.Atoi(args[1])
        if err != nil {
            fmt.Println("Second parameter is not a valid number.")
            return
        }
    }
    if len(args)==3{
        index_name = args[2]
    }

    //Read all the files (full path) that the root directory contains
    fmt.Println("EXTRACTING DATA (reading (full path) files names)")
    var emailXTObj EmailExtractor
    emailXTObj.RootDir = args[0]
    list_of_files = ExtractData(emailXTObj)


    if num_file_to_read > len(list_of_files) || num_file_to_read < 1{
        num_file_to_read = len(list_of_files)    
    }
    if index_name == ""{
        index_name = rnd_prefix + "index"
    }

    fmt.Println("TRASFORMING DATA INTO TEMPORAL REPOSITORIES (JSON FORMAT)")

    var emailTxObj EmailTransformer
    emailTxObj.List_of_files = list_of_files
    emailTxObj.Num_file_to_read = num_file_to_read
    emailTxObj.Key_map = key_map
    emailTxObj.Index_name = index_name
    emailTxObj.Repo_prefix = rnd_prefix
    
    var emailLxObj EmailLoader
    emailLxObj.Url = "http://localhost:4080/api/_bulk"
    emailLxObj.User = "admin"
    emailLxObj.Pwd = "Complexpass#123"
    emailLxObj.List_repo_name = TransformData(emailTxObj)
    LoadData(emailLxObj)
   
    elapsed := time.Since(start)
    log.Printf("Elapsed time: %s", elapsed)

}

func createPrefix() string {
    rand.Seed(time.Now().UnixNano())
    charset := "abcdefghijklmnopqrstuvwxyz"
    a := charset[rand.Intn(len(charset))]
    b := charset[rand.Intn(len(charset))]
    c := charset[rand.Intn(len(charset))]
    d := charset[rand.Intn(len(charset))]
    return string(a) + string(b) + string(c) + string(d) + "_"
}


