<template>
  <div id="app" class="container mx-auto bg-gray-200 rounded-xl shadow border p-8 m-10">
    <div class="row"  style="width: 1200px">
      <h1>SEARCH IN THE EMAIL DATABASE</h1>
      <div class="col-md-6 offset-md-3 py-5">
        <br/>
        <form v-on:submit.prevent="searchDocument">
          <div class="-mx-3 md:flex mb-2">
              <div class="md:w-1/1 px-3 mb-6 md:mb-0" style="width:522px">
                  <ListOfIndexes @selectindex="indexSelect($event)"> </ListOfIndexes>
              </div>
              <div class="md:w-1/2 px-3 mb-6 md:mb-0">
                  <input v-model="keyword" type="text" id="website-input" placeholder="Enter a keyword" class="appearance-none block w-full bg-grey-lighter text-grey-darker border border-grey-lighter rounded py-3 px-4" style="width: 420px">
              </div>
              <div class="md:w-1/2 px-3 mb-6 md:mb-0">
                  <button class="block w-full transform rounded-md bg-teal-400 px-4 py-2 text-center font-medium capitalize tracking-wide text-white transition-colors duration-300 hover:bg-teal-500 focus:outline-none focus:ring focus:ring-teal-300 focus:ring-opacity-80" style="width: 100px">Search</button>
              </div>    
          </div>
        </form>
      </div>
      <h2>Results: {{ Mensajes.count }}</h2>
    </div>
  </div>
  <div class="md:px-32 py-8 w-full">
    <div class="shadow overflow-hidden rounded border-b border-gray-200">
      <table class="min-w-full bg-white" :items="Mensajes.details" :fields="fields">
      <thead class="bg-gray-800 text-white">
        <tr>
          <th class="w-3/20 text-left py-3 px-4 uppercase font-semibold text-sm" scope="col">Date</th>
          <th class="w-3/20 text-left py-3 px-4 uppercase font-semibold text-sm" scope="col" width="150px">From</th>
          <th class="w-3/20 text-left py-3 px-4 uppercase font-semibold text-sm" scope="col" width="150px">To</th>
          <th class="w-3/20 text-left py-3 px-4 uppercase font-semibold text-sm" scope="col" width="200px">Subject</th>
          <th class="w-8/20 text-left py-3 px-4 uppercase font-semibold text-sm" scope="col" width="650px">Body</th>
        </tr>
      </thead>
      <tbody>
        <tr v-for="msj in Mensajes.details" v-bind:key="msj.MessageID">          
          <td class="w-3/20">{{ msj.Date }}</td>
          <td class="w-3/20">{{ msj.From }}</td>
          <td class="w-3/20">{{ msj.To }}</td>
          <td class="w-3/20">{{ msj.Subject }} </td>                    
          <td class="w-8/20">{{ msj.Body }} </td>                    
        </tr>
      </tbody>
    </table> 
    </div>
  </div>
</template>

<script>
import ListOfIndexes from './components/ListOfIndexes.vue'

export default {

  components: {
    ListOfIndexes
  },

  name: 'App',

  data() { return {
             fields: ['Date', 'From', 'Subject', 'To', 'Body', 'MessageID'],
             Date: "",
             From: "",
             Subject: "",
             To: "",
             Body: "",
             MessageID: "",        
             count: 0,
             details: [],
             Mensajes: ['count','details'],
             indexName: ""
  } },
  methods: {
    indexSelect(e){
      this.indexName = e
    }, 
    searchDocument() {
      const requestOptions = {
        method: "GET",
        headers: { "Content-Type": "application/json" }
      };
      fetch("http://localhost:8080/entries?index=" + this.indexName + "&keyword=" + this.keyword, requestOptions)
      .then(function(response) {
        return response.json();
      })
      .then((data) =>{
       this.Mensajes = data;
       console.log(this.Mensajes);
      })
      .catch((error) => {
        window.alert(`The API returned an error: ${error}`);
      })
    }
  }
}
</script>

