<template>
  <div id="app" class=" w-full flex justify-center">
    <div class="container">
        <form v-on:submit.prevent="LoadListIndex">
           <div class="-mx-3 md:flex mb-2">
              <div class="md:w-1/1 px-2">
                 <button class="block w-full transform rounded-md bg-teal-400 px-4 py-2 text-center font-medium capitalize tracking-wide text-white transition-colors duration-300 hover:bg-teal-500 focus:outline-none focus:ring focus:ring-teal-300 focus:ring-opacity-80"  style="width: 100px">Refresh</button>
              </div>
              <div class="md:w-2/2 px-3">
                 <div class="relative">
                   <select v-model="name" id="selectIndex" @change="changeIndex($event)"  class="block appearance-none w-full bg-grey-lighter border border-grey-lighter text-grey-darker py-3 px-4 pr-8 rounded" style="width:222px">
                   <option
                   v-for="item in Indexes" :key="item.name" :value="item.name">
                   {{ item.name }} 
                   </option>
                   </select>
                   <div class="pointer-events-none absolute pin-y pin-r flex items-center px-2 text-grey-darker">
                     <svg class="h-4 w-4" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 20 20"><path d="M9.293 12.95l.707.707L15.657 8l-1.414-1.414L10 10.828 5.757 6.586 4.343 8z"/></svg>
                   </div>
                 </div>
              </div>
           </div>
        </form>
    </div>
  </div>
</template>

<script>
export default {
  name: 'App',
  data() { return {
             fields: ['name'],
             name: "",        
             Indexes: [],
             selectedIndex: null
  } },
  methods: {
    changeIndex (event) {
      this.selectedIndex = event.target.options[event.target.options.selectedIndex].text
      this.$emit("selectindex", this.selectedIndex)
    },
    LoadListIndex() {
      const requestOptions = {
        method: "GET",
        headers: { "Content-Type": "application/json" }
      };
      fetch("http://localhost:8080/entries/indexes?index=", requestOptions)
      .then(function(response) {
        return response.json();
      })
      .then((data) =>{
       this.Indexes = data;
       console.log(this.Indexes);
      })
      .catch((error) => {
        window.alert(`The API returned an error: ${error}`);
      })
    }
  }
}
</script>
