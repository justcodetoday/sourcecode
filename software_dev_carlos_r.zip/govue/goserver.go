package main

import (
	"github.com/go-chi/chi/v5"
  	"net/http"
  	"io"
	"log"
	"fmt"
	"strings"
	"encoding/json"
)

// GO Server's response to the client  
type respBackend struct {
	Count int `json:"count"`				//Number of the search results
	Details []_source `json:"details"`		//Array of emails which contains the keyword asked by the client
}

type _source struct {
	Date string `json:"Date"`
	From string  `json:"From"`
	Subject string `json:"Subject"`
	To string `json:"To"`
	Body string `json:"Body"`
	MessageID string `json:"Message-ID"`
}

// ZSE response for the GO server
type respFromZSE struct{
	Took string `json:"took"`
	Timed_out string `json:"timed_out"`
	Shards _shards `json:"_shards"`
	Hits hits `json:"hits"`
}

type hit struct {
	Index string `json:"_index"`
	Type string `json:"_type"`
	Id string `json:"_id"`
	Score string `json:"_score"`
	Timestamp string `json:"@timestamp"`
	Source _source `json:"_source"`
}
  
type _shards struct {
	Total int `json:"total"`
	Successful int `json:"successful"`
	Skipped int `json:"skipped"`
	Failed int `json:"failed"`
}
  
type total struct {
	Value int `json:"value"`
}
  
type hits struct {
	Total total `json:"total"`
	Max_score int `json:"max_score"`
	Hits []hit `json:"hits"`
}
  

type entryResource struct{}

// List of Indexes that are stored in the ZSE
type listIndex struct{
	List []list `json:"list"`
	Page page `json:"page"`
}

type list struct {
	Name string `json:"name"`
    Storage_type string `json:"storage_type"`
    Shard_num int `json:"shard_num"`
    Settings setting `json:"settings"`
    Mappings mapping `json:"mappings"`
}

type setting struct {
}

type mapping struct {
	Properties property `json:"properties"`
    Stats stat `json:"stats"`
}

type property struct{
	Timestamp timestamp `json:"@timestamp"`
	Id _id `json:"_id"`
	Chunk chunk `json:"chunk"`
	Retry_times retry_times `json:"retry_times"`
}

type stat struct {
	Doc_time_min int `json:"doc_time_min"`
	Doc_time_max int `json:"doc_time_max"`
	Doc_num int `json:"doc_num"`
	Storage_size int `json:"storage_size"`
	Wal_size int `json:"wal_size"`
}

type timestamp struct{
	Type string `json:"type"`
	Index bool `json:"index"`
	Store bool `json:"store"`
	Sortable bool `json:"sortable"`
	Aggregatable bool `json:"aggregatable"`
	Highlightable bool `json:"highlightable"`
}
type _id struct {
	Type string `json:"type"`
	Index bool `json:"index"`
	Store bool `json:"store"`
	Sortable bool `json:"sortable"`
	Aggregatable bool `json:"aggregatable"`
	Highlightable bool `json:"highlightable"`
}
type chunk struct {
	Type string `json:"type"`
	Index bool `json:"index"`
	Store bool `json:"store"`
	Sortable bool `json:"sortable"`
	Aggregatable bool `json:"aggregatable"`
	Highlightable bool `json:"highlightable"`
}
type retry_times struct {
	Type int `json:"type"`
	Index bool `json:"index"`
	Store  bool `json:"store"`
	Sortable bool `json:"sortable"`
	Aggregatable bool `json:"aggregatable"`
	Highlightable bool `json:"highlightable"`
}

type page struct{
	Page_num int `json:"page_num"`
	Page_size int `json:"page_size"`
	Total int `json:"total"`
}

type index struct {
	Name string `json:"name"`
}

func main() {
	port := "8080"
  	log.Printf("Backend GO - Starting up on http://localhost:%s", port)
	r := chi.NewRouter()
    r.Use(Cors)  
	r.Get("/", func(w http.ResponseWriter, r *http.Request) {
	  w.Header().Set("Content-Type", "text/plain")
	})
	r.Mount("/entries", entryResource{}.Routes())
	log.Fatal(http.ListenAndServe(":" + port, r))
}

func Cors(next http.Handler) http.Handler {
    return http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
        w.Header().Set("Access-Control-Allow-Origin", "*")
		w.Header().Set("Access-Control-Allow-Methods", "POST,GET,OPTIONS,PUT,DELETE");
		w.Header().Set("Access-Control-Allow-Headers", "*")

        if r.Method == "OPTIONS" {
            return
        }
        next.ServeHTTP(w, r)
    })
}

func (rs entryResource) Routes() chi.Router {
	r := chi.NewRouter()
	r.Get("/", rs.Search)    			
	r.Get("/indexes", rs.ListIndexes)   
    return r
}

// Request Handler - Read all the indexes that database contains.
func (rs entryResource) ListIndexes(w http.ResponseWriter, r *http.Request) {
	var responseObject listIndex
	var respJsonObject []index
	var respJsonItem index
    req, err := http.NewRequest("GET", "http://localhost:4080/api/index?page_num=1&page_size=20&sort_by=name&desc=false", nil)
	if err != nil {
		log.Fatal(err)
	}
	req.SetBasicAuth("admin", "Complexpass#123")
	req.Header.Set("Content-Type", "application/json")
	req.Header.Set("User-Agent", "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_4) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/81.0.4044.138 Safari/537.36")

	resp, err := http.DefaultClient.Do(req)
	if err != nil {
		log.Fatal(err)
	}
	defer resp.Body.Close()
	
	w.Header().Set("Content-Type", "application/json")
	w.WriteHeader(http.StatusOK)

	responseData, err := io.ReadAll(resp.Body)
	if err != nil {
		log.Fatal(err)
	}
	json.Unmarshal(responseData, &responseObject)		

	for i := 0; i < len(responseObject.List); i++ {
		respJsonItem = index {responseObject.List[i].Name}
		respJsonObject =  append(respJsonObject, respJsonItem)
	}
	data, err := json.Marshal(respJsonObject)
	if err != nil {
		log.Fatal(err)
	}
	w.Write(data)
	fmt.Println("List of Indexes in ZSE")
	fmt.Println(respJsonObject)

}

// Request Handler - Search a keyword in the ZSE database 
func (rs entryResource) Search(w http.ResponseWriter, r *http.Request) {
	var responseObject respFromZSE
	var respJsonObject []_source
	var respJsonItem _source

	id := r.URL.Query().Get("index")
	keyword := r.URL.Query().Get("keyword")
	query := `{
		"search_type": "matchphrase",
		"query":
		{
			"term": "` + keyword + `"
		},
		"from": 0,
		"max_results": 100000,
		"_source": ["From", "To", "Subject", "Date", "Body", "Message-ID"]
		}`
	req, err := http.NewRequest("POST", "http://localhost:4080/api/" + id + "/_search", strings.NewReader(query))
	if err != nil {
		log.Fatal(err)
	}
	req.SetBasicAuth("admin", "Complexpass#123")
	req.Header.Set("Content-Type", "application/json")
	req.Header.Set("User-Agent", "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_4) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/81.0.4044.138 Safari/537.36")

	resp, err := http.DefaultClient.Do(req)
	if err != nil {
		log.Fatal(err)
	}
	defer resp.Body.Close()
	
	w.Header().Set("Content-Type", "application/json")
	w.WriteHeader(http.StatusOK)

	responseData, err := io.ReadAll(resp.Body)
	if err != nil {
		log.Fatal(err)
	}
	json.Unmarshal(responseData, &responseObject)		
	for i := 0; i < len(responseObject.Hits.Hits); i++ {
		respJsonItem = _source {
		responseObject.Hits.Hits[i].Source.Date,
		responseObject.Hits.Hits[i].Source.From,
		responseObject.Hits.Hits[i].Source.Subject,
		responseObject.Hits.Hits[i].Source.To,
		responseObject.Hits.Hits[i].Source.Body,
		responseObject.Hits.Hits[i].Source.MessageID}
		respJsonObject =  append(respJsonObject,respJsonItem)
	}
	respJsonObj := respBackend{len(respJsonObject), respJsonObject}
	data, err := json.Marshal(respJsonObj)
	if err != nil {
		log.Fatal(err)
	}
	w.Write(data)
}
 
